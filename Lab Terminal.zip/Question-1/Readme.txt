We will implement jquery form handling to tackle authenticatio.
Due to shortage of time I was not able to make API call 