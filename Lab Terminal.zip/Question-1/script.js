$(document).ready(function() {
    $("#basic-form").validate();
});



